import java.io.*;
import java.util.*;
import java.sql.*;
import java.math.*;
class Convertion
{
	private  Statement st=null;
	private  ResultSet rs9=null;  

    Convertion()
	{
	   DbConnection db=new DbConnection();
		st=db.DBConnect();
	}
   
	public void conver()
	{
		try
		{
			rs9=st.executeQuery("select * from privatekeytable where uno='1'");
          System.out.println(" result set is "+rs9);
		   if(rs9.next())
			{
			   String ls=rs9.getString(2);
		       byte[] theByteArray = ls.getBytes(); 
		        BigInteger bi=new BigInteger(theByteArray);
				System.out.println(" Values is "+bi);
			}
		         
		      
		} 
		catch (Exception es)
		{
			es.printStackTrace();
		}
	}
	
	public static void main(String[] args) 
	{
		 Convertion x=new Convertion();
		 x.conver();
	}
}
