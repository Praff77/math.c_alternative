import java.sql.*;
import java.util.*;
public class CreatePrimaryKeySet 
{
	public Statement st=null;
	public ResultSet rs=null;
	public int nuser;
	public int ai=1;
	public int id=1;
    public String pc="",pc1="",pc2="";
	public ArrayList ls;
	public CreatePrimaryKeySet()
	{
		DbConnection dc=new DbConnection();
		st=dc.DBConnect();
		ls=new ArrayList();
	    
	}
	
	public  void createKeySet(int user) 
	{
	    try
	    {
		  ls.add(0,"zere");	
	     rs=st.executeQuery("select * from privatekeytable ");
		 while(rs.next())
				{
				 pc=rs.getString(2);
				ls.add(ai,pc);
				ai++;
				}  

        System.out.println("Array list values is "+ls);

		 nuser=user;
		int k=2;
		for(int i=1;i<=nuser;i++)
		{
			for(int j=k;j<=nuser;j++)
			{
			
		   // pc="";
			pc=(String)ls.get(i)+"#";
			pc1=(String)ls.get(j);
			
			//pc2=pc.concat(pc1);
			pc2=pc+pc1;
			st.executeUpdate("insert into privatekeyset values('"+id+"','"+i+","+j+"','"+pc2+"')");
			pc="";
			pc1="";
			pc2="";
			System.out.println("i= "+i+" j= "+j);
			id++;
			}
	        k++;
		}
	  
	  }
	    catch (Exception el)
	    {
			el.printStackTrace();
	    }
	  
	}
   
}
