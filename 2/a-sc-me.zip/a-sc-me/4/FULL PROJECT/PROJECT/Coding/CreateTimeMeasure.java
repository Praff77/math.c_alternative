import javax.swing.*;
import java.awt.*;
import java.sql.*;
import javax.swing.table.*; 
import java.net.*;
import java.io.*;

public class CreateTimeMeasure{
  
  int row=0;
Statement st;
JTable jTable1;
String sname="";
private JScrollPane jScrollPane1; 
  
 public void getServerHostName()
	 {

		try
		{

			FileInputStream fis=new FileInputStream("server.txt");
			byte b[]=new byte[fis.available()];
			fis.read(b);
		    sname= new String(b);
			System.out.println("SERVER NAME IS "+sname);

		}

		catch (Exception e)
		{
		}
	
	}




  public static void main(String[] args) {
    CreateTimeMeasure r = new CreateTimeMeasure();
  }

  public CreateTimeMeasure(){
   
	
	//DbConnection db=new DbConnection();
	//	st=db.DBConnect();
	
	JRadioButton Male,Female;
    JFrame frame = new JFrame("Measurement of Encrypt and Decrypt Time");
    JPanel panel = new JPanel();
	jScrollPane1 = new JScrollPane(); 

  /*  ButtonGroup buttonGroup = new ButtonGroup();
    Male = new JRadioButton("Male");
    buttonGroup.add(Male);
    panel.add(Male);
    Female = new JRadioButton("Female");
    buttonGroup.add(Female);
    panel.add(Female);
    Male.setSelected(true);*/
  
	String  t[] = {"NoPkey","KeySize","DataSize","EncTime","DecTime"};
		
	
    try
		    {
				getServerHostName();
		   
               Socket es1 = new Socket(sname,9876);
			   ObjectOutputStream en1 = new  ObjectOutputStream(es1.getOutputStream());
		       ObjectInputStream en2=new ObjectInputStream(es1.getInputStream());
			   en1.writeObject("1");
			   en1.writeObject("timemeasure");
               String gve[][]=(String[][])en2.readObject();
		       
			   en1.writeObject("");
			   en1.writeObject("");
			   en1.writeObject("");
               es1.close();

              jTable1 = new JTable(gve,t);
             }
		    catch (Exception esc)
		    {
				esc.printStackTrace();
		    }

	
	/*
	
	
	
	try
		{
			
			ResultSet rt=st.executeQuery("select * from timecal");
			while(rt.next())
			{
				row++;
			}
		}
		catch (Exception ew)
		{
			ew.printStackTrace();
		}
 		String d[][] = new String[row][5];
		String t[] = {"NoPkey","KeySize","DataSize","EncTime","DecTime"};
		try
		{
			
			int j = 0;
			ResultSet rst = st.executeQuery("select * from timecal");
			while(rst.next())
			{
				d[j][0] = rst.getString(1);
				d[j][1] = rst.getString(2);
				d[j][2] = rst.getString(3);
				d[j][3] = rst.getString(4);
				d[j][4] = rst.getString(5);
				j++;
			}
			//con.close();
		}
		catch(Exception ex9)
		{
			System.out.println(ex9);
		}      */


		//jTable1 = new JTable(d,t);
 		jScrollPane1.setViewportView(jTable1); 
		
	
	   // panel.add(jTable1);
		//panel.add(jScrollPane1);
		//pane1
	
	
	 
//	frame.add(panel);
   frame.add(jScrollPane1);
	frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    frame.setSize(400,150);
    frame.setVisible(true);
  }
}