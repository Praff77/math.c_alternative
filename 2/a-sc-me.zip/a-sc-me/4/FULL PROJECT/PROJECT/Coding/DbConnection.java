import java.sql.*;
public class DbConnection
{
     public Connection con=null ;   
	 public Statement st=null;
	 public Statement DBConnect()
	 {
		try
		{
			Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
			con=DriverManager.getConnection("jdbc:odbc:smock","sa","");
			st = con.createStatement();
		}
		catch(Exception e)
			{
			  e.printStackTrace();
			}
		return st;
	}
}