import java.math.*; 
 
/** 
 * <p>Title:Class Decrypt</p> 
 * <p>Description: This class decrypts a ciphertext with the given  
 * public and private keys. (d,n)</p> 
 * <p>Author: Radhika Reddy</p> 
 */ 
public class Decrypt{ 
 
 /** 
   * Default Class Constructor. 
   * Uses predefined public and private keys. 
  */ 
 public Decrypt(){ 
   
  /** 
     * Following keys were generated at 
http://crypto.cs.mcgill.ca/~crepeau/RSA/generator_frame.html 
   */ 
  publickey_n = new BigInteger("87804687216282445014344449262787492088471510759278970766557708167685450735849");  
  publickey_d = new BigInteger("59773221267454873409080055372070998244169751182929627179176156213454118330409");  
   
  doDecryption(); 
  }
    
 /** 
   * Class Constructor. 
   * The method takes two parameters (private and public key) 
   * and decrypts the cipher text created by the encryption  
   * class Encrypt. The default file with the ciphertext is 
   * "encrypt.txt". The default output goes to "decrypt.txt" 
   * @param d private key 
   * @param n public key 
  */  
  public Decrypt(BigInteger d, BigInteger n){ 
       //set the private and public keys based on input 
  publickey_d = d; 
  publickey_n = n; 
   
  doDecryption(); 
 } 
 
 /**  
   * Class Constructor with keys and input filename provided. 
   * This method takes three parameters (input filepath, and  
   * public key n and private key d). It decrypts the ciphertext using the  
   * keys and writes the output to file "decrypt.txt". 
   * @param filename Input/Plaintext filepath 
   * @param d private key 
   * @param n public key 
  */ 
  public Decrypt(String filename, String d, String n){ 
 
    //set the private and public keys based on input 
    publickey_d = new BigInteger(d); 
    publickey_n = new BigInteger(n); 
   
  ciphertxt = filename; 
    
  doDecryption(); 
 } 
 
 
 /** 
   * This method performs the main actions of calling the IO class 
   * and decrypting the ciphertext 
  */ 
  public void doDecryption(){ 
    String temp_str = new String(); 
      
  //perform IO 
    IO io = new IO(ciphertxt, outtxt); 
   
  //read the ciphertext file 
  io.openCipher();    
  
    //read each line of cipher text and decode it with the keys provided 
    while( (temp_str = io.nextLine()) != null) { 
    
      BigInteger ciphertext = new BigInteger(temp_str); 
   String x = io.decryptText(ciphertext, publickey_d, publickey_n);     
   //write decoded text to output file 
   io.writeOut(io.decodeString(x)); 
  } 
         io.closeFile();    //close output file 
 }  //end doDecryption 
 
 /** 
   * Main function to run the Decryption program directly 
  */ 
  public static void main (String args[]) { 
   
  int len; 
     len = args.length; 
   
     if(len != 3){ 
       System.out.println("No arguments provided. Default keys and fileswill be used."); 
       System.out.println("Command format is <Encrypt plaintext privatekey_d publickey_n"); 
    Decrypt decrypt = new Decrypt();    
	   } 
   else { 
       Decrypt decrypt = new Decrypt(args[0], args[1], args[2]); 
 //user input 
   } 
 } //end main 
 
 /*  
   * Data Members 
  */ 
  private BigInteger publickey_d; 
  private BigInteger publickey_n; 
  //default filenames for ciphertext and final output 
  private String ciphertxt = "encrypt.txt"; 
  private String outtxt   = "decrypt.txt"; 
  
}  //end class Decrypt 
 
 