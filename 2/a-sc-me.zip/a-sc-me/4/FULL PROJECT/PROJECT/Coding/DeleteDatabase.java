import java.sql.*;
class DeleteDatabase 
{
	Statement st=null;
	public DeleteDatabase()
	{
	 try
	 {
		
	
		DbConnection db=new DbConnection();
		st=db.DBConnect();
		st.executeUpdate("delete from login");
		st.executeUpdate("delete from privatekeytable");
		st.executeUpdate("delete from publickeytable");
		st.executeUpdate("delete from privatekeyset");
		st.executeUpdate("delete from timecal");
	    st.executeUpdate("delete from keysize");
        

	 }
	 catch (Exception e)
	 {
		 e.printStackTrace();
	 }
	
	}

  public static void main(String[] args) 
	{
	  new DeleteDatabase();
	}

}
