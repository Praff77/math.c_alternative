import java.io.*;
public class FindKeySize 
{
	private int user;
	public FindKeySize(int kk)
	{
		user=kk;
	 
	}

	public int keySize()
	{
	 try
	   {
		 //user=kk;
		//	DataInputStream in=new DataInputStream(System.in);
	     System.out.println("Number of user is "+user);
		//int user=Integer.parseInt(in.readLine());
		int key;
		int a=1;                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              

		for(int i=1,j=2;i<=user;i++,j++)
		{
         
		 if(user<=a)
			{
			   key=j;
			   System.out.println(" Key values is "+key);
			   
			   return key;
			  //System.exit(0);
			}
		  a+=j;
	    }
	  
	   }
	  catch (Exception e)
		{
		   e.printStackTrace();

		}
	  return 0;
	}
}
