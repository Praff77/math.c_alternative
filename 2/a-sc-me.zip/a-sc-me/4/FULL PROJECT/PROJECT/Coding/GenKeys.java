/****************************************************************/
/*                      key	                            */
/*                                                              */
/****************************************************************/
import java.math.BigInteger;
import java.util.*;


class calculation
{
	 long great,a;
	 double aa,bb,cc,rm;
	 long rd;
	 long eval;
	 long calE(long pi,long p,long q)
	 {

		  great=0;
		  aa=Math.log(pi)/Math.log(10);

//		  System.out.println("AA :"+aa);
		  bb=Math.floor(aa);
//		  		  System.out.println("BB :"+bb);
		  cc=Math.pow(10,bb);
//		  		  System.out.println("CC :"+cc);
		  rm=Math.random()*cc;

//		  System.out.println("rm :"+rm);
		  rd=Math.round(rm);
//		  System.out.println("rd :"+rd);
		  while(great != 1)
		  {
	//		  System.out.println("While loop :");

			   rd=rd+1;
			//   System.out.println("RD  +1 :"+rd);

			   great=GCD(rd,pi);
		//	   System.out.println("GREATE :"+great);
			   pi=(p-1)*(q-1);
			//   System.out.println( "PI :"+pi);
		  }
		  return rd;
	 }

	 long GCD(long e,long pi)
	 {
//		System.out.println("e :"+e);
//		System.out.println(" PI :"+pi);
		  if(e > pi)
		  {
	//		  System.out.println("IF loop :");
			   while(e%pi != 0)
			   {
		//		   System.out.println("WHILE LOOP :");
					a=e%pi;
			//		System.out.println(" A:"+a);
					e=pi;
			//		System.out.println(" E==>"+e);
					pi=a;
			//		System.out.println( " PI=>"+pi);
			   }
//			   System.out.println("END IF");
			   great=pi;
//			   System.out.println("ASSIGN VAL :"+great);
		  }
		  else
		  {
		//	  System.out.println("ELSE LOOP");
			   while(pi%e != 0)
			   {
		//			System.out.println("WHILE LOOP :");
					a=pi%e;
			//		System.out.println("a :"+a);
					pi=e;
			//		System.out.println("pi :"+pi);
					e=a;
			//		System.out.println("e12 :"+e);
			   }
			   great=e;
			   new Message();
		  }
		  return great;
	 }
}

public class GenKeys 
{

	String pstr = "";
	String qstr = "";
	String s, output;
	long p,q,pi,e,val,ds,r,qd;;
	static long d,n;
	int i,cnt,inc=0;
	long rst[] = new long[100];
	long div[] = new long[100];
	long qud[] = new long[100];
	long rem[] = new long[100];
	String fe = "";
	String fd = "";
	String fn = "";
	String PubKey = "";
	String PriKey = "";
	String concat="";
		// End of variables declaration
	
	GenKeys()
	{		
	}

	public String getKeys()
	{
		calculation cal = new calculation();
		Random rnd1 = new Random(0);
		Random rnd2 = new Random(0);
		BigInteger prime1 = BigInteger.probablePrime(10, rnd1);
		BigInteger prime2 = BigInteger.probablePrime(15, rnd2);
//		System.out.println("Ramdom 1 "+rnd1);
//		System.out.println("Ramdom 2 "+rnd2);
		p = prime1.longValue();
		q = prime2.longValue();

		System.out.println(p);
		System.out.println(q);

			 n=p*q;

	//		 System.out.println("N :"+n);

			 pi=(p-1)*(q-1);

//			 System.out.println("PI :"+pi);
			 
//			 System.out.println(" PI value :"+pi);

  			 e=cal.calE(pi,p,q);
//  			 System.out.println("e :"+e);
			qd=pi/e;
//			System.out.println("QD:"+qd);
			r=pi%e;

//			System.out.println("R :"+r);
   			cnt=0;
   			rst[cnt]=pi;
   			div[cnt]=e;
   			qud[cnt]=qd;
   			rem[cnt]=r;
			//System.out.println("val	ds	qd	r");
   			do
   			{
//				System.out.println("DO LOOP");
				cnt++;
				val=div[cnt-1];	//val=e
		//		System.out.println("VAL :"+val);
				ds=rem[cnt-1];//ds = r
		//		System.out.println("DS :"+ds);
				qd=val/ds; // qd=e/r
		//		System.out.println("QD :"+qd);
				r=val%ds;  //  r=e%r
//				System.out.println("R :"+r);
				//System.out.println(val+"\t"+ds+"\t"+qd+"\t"+r);
				if(r != 0)
				{
//					System.out.println("DO IF  LOOP");
					 rst[cnt]=val;		//e
					 div[cnt]=ds;		//r
					 qud[cnt]=qd;		//e/r
					 rem[cnt]=r; 		//e%r
				}
//				System.out.println("END IF :");
			}while(r != 0);
			long p1,q1,s1,t1,p2,q2,s2,t;

			p1=rst[cnt-1];
	//		System.out.println("P1 :"+p1);
			q1=-qud[cnt-1];
	//		System.out.println("Q1 :"+q1);
			s1=div[cnt-1];
	//		System.out.println("S1 :"+s1);
			t=1;
	//		System.out.println("T :"+t);

			for(i=(cnt-2);i>=0;i--)
			{
 //				System.out.println("FOR LOOP :");
				 p2=rst[i];
		//		 System.out.println("P2 :"+p2);
				 q2=-qud[i];
		//		 System.out.println("Q2 :"+q2);
				 s2=div[i];
		//		 System.out.println("S2 :"+s2);
				 if(s1==rem[i])
				 {
//					 System.out.println("IF LOOP");
				   if(p1==s2)
	   				{
			//		   System.out.println("IF LOOP");
						p1=p2;
			//			System.out.println("P1 :"+p1);
						t1=t;
			//			System.out.println("T1 :"+t1);
						t=q1;
			//			System.out.println("T :"+t);
						q1=t1+(q1*q2);
			//			System.out.println("Q1 :"+q1);
						s1=s2;
			//			System.out.println("S1 :"+s1);
	   				}
				 }
			}
			if(q1<0)
				 d=pi+q1;
			else
				 d=q1;
				fe = String.valueOf(e);
				System.out.println("FE :"+fe);
				fd = String.valueOf(d);
				System.out.println("FD :"+fd);
				fn = String.valueOf(n);
				System.out.println("FN :"+fn);
		
				//output ="\n\nPublic +Key :"+"\n   Exponent Value (e) = "+fe+"\n   N Value (n)        ="+fn+"\n\nPrivate Key :"+"\n  Decryption Key (d)  ="+fd+"\n  N Value (n)         ="+fn;
	            //         System.out.println(output);
				inc++;
				if(inc==10)
					inc=0;
				else
				{
					System.out.println("FD:"+fd);
					if(fd.length()==7)
					fd+=inc; 
					System.out.println("FD  + :"+fd);
					if(fd.length()==6)
					{
						//String s=Convert.intToString(inc,);
						fd=fd+inc;
						System.out.println("FD "+fd);
						//fd = String.valueOf(fd);
						System.out.println("FD "+fd);
						fd+=inc;
						System.out.println("FD "+fd);
					}
					if(fd.length()==5)
					{
						fd+=inc;
						System.out.println("FD "+fd);
						fd+=inc;
						System.out.println("FD "+fd);
						fd+=inc;
						System.out.println("FD "+fd);
					}
					concat+=fd+"#";
					System.out.println("The Public key is "+concat);
				}
				return concat;
	}

//============================= Testing ================================//
//=                                                                    =//
//= The following main method is just for testing this class you built.=//
//= After testing,you may simply delete it.                            =//
//======================================================================//
	public static void main(String[] args)
	{
		//GenKeys gd = new GenKeys();
		//for(int i=0;i<2;i++)
		//gd.getKeys();
	}



}
