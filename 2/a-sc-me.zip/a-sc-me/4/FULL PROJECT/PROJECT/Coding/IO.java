import java.io.*; 
import java.lang.Byte; 
import java.math.*; 
 
/** 
 * <p>Title:Class IO</p> 
 * <p>Description: This class handles input-output for testing 
 * the RSA algorithm</p> 
 * <p>Author: Radhika Reddy</p> 
 */ 
public class IO{ 
  
 /** 
   * Default constructor. 
   * Sets the input and output files to the defualt names 
   * "input.txt" and "encrypt.txt" 
  */ 
 public IO(){ 
    input = new File(in); 
    output = new File(out); 
 } 
  
 /** 
   * Constructor that accepts the input and output filenames. 
   * @param in_file Input filename 
   * @param out_file Output filename 
  */ 
  public IO(String in_file, String out_file){ 
  in = in_file; 
  out = out_file; 
 } 
  
 /** 
   * Open the plain text file and the cipher text file for writing output. 
  */ 
  public void openPlaintext(){ 
   
  //open plaintext file for encryption 
    input = new File(in); 
    //open ciphertext file for output 
    output = new File(out); 
   
    //read in input and prepare output file for writing 
  try {    reader = new FileReader(input); 
   buffer = new BufferedReader(reader); 
   writer = new FileWriter(output);   
    } catch (FileNotFoundException fnfe) { 
      System.out.println("File not found: " + fnfe.getMessage()); 
    } catch (IOException ioe) { 
   System.out.println("IOException: " + ioe.getMessage()); 
   
  } 
 } //end openPlaintext   
     
 
 /** 
   * Read next Line from input file 
   * @return String containing the next line  
  */ 
  public String nextLine(){ 
 
        try { aString = buffer.readLine(); } 
        catch(IOException ioe) { 
          System.out.println("IOException: " + ioe.getMessage());  
        } 
  return aString; 
 } //end nextLine 
  
 /** 
   * Write encoded text to the ciphertext file. 
   * @param str String containing encoded text 
  */           
       
  public void writeCipher(String str){ 
  try {  
   writer.write(str); 
   writer.write("\r\n"); 
  }catch (IOException ioe) { 
   System.out.println("IOException: " + ioe.getMessage());   
  } 
 } //end writeCipher 
 
 /** 
   * Write decoded text to the decrypted file. 
   * @param str String containing decoded text  
  */ 
  public void writeOut(String str){ 
  try {  
   writer.write(str);   }catch (IOException ioe) { 
   System.out.println("IOException: " + ioe.getMessage());   
  } 
 } //end writeOut 
   
 /** 
   * Open the ciphertext file for reading 
  */   
  public void openCipher(){ 
    input = new File(in); 
    output = new File(out); 
    //read in input and prepare output file for writing 
  try { 
   reader = new FileReader(input); 
   buffer = new BufferedReader(reader); 
   writer = new FileWriter(output);   
    } catch (FileNotFoundException fnfe) { 
      System.out.println("File not found: " + fnfe.getMessage()); 
    } catch (IOException ioe) { 
   System.out.println("IOException: " + ioe.getMessage()); 
  } 
 } //end openCipher 
   
 /** 
   * Close all open file that were written to. 
  */          
    public void closeFile(){ 
       //close the output file  
      try {  
     writer.close();  
      } catch(IOException ioe) {  
      System.out.println("IOException: " + ioe.getMessage()); 
	  } 
      //let the user know where we have written the file 
      System.out.println("Output writen to " + out + "\n"); 
 } //end closeFile 
   
 
    /** 
     * Method to divide each line read from the plaintext file 
     * into 16 character blocks. 
     * @param s String containing line read 
     * @param chunks Array to hold each line, 16 chars at a time 
     */  
   public static String[] breakUpString(String s, int chunks){ 
       String temp[] = new String[chunks]; 
    
    int first = 0, last = 16;  
   
  if(last > s.length()){ 
   last = s.length(); 
  } 
  
     //break each line into blocks on 16 chars each. 
    for(int i = 0; i < chunks; i++){       
   temp[i] = s.substring(first,last); 
   first = last; 
   last += 16; 
      if(last > s.length()) last = s.length();  
  } 
   
  return temp; 
 } //end breaUpString 
  
 /** 
   * Encrypt the text using E(p) = p^e mod n. 
   * @param ascii_val Plaintext value in bytes 
   * @param e Private key e 
   * @param n Public Key n 
  */ 
  public String encryptText(BigInteger ascii_val, BigInteger e, BigInteger n){ 
    if ( print_key_flag == 0){ 
   System.out.println("Keys used for Encryption:\n"); 
      System.out.println("Public key n: " + n); 
      System.out.println("Private key e: " + e); 
   print_key_flag++; 
  } 
     
  return (ascii_val.modPow(e,n)).toString(); 
 } //end encryptText 
 
 /** 
   * Decrypt the text using D(c) = c^d mod n. 
   * @param ciphertext Encoded text 
   * @param d Private key d 
   * @param n Public key n 
  */ 
  public String decryptText(BigInteger ciphertext, BigInteger d, BigInteger n){ 
    if (print_key_flag == 0){ 
   System.out.println("Keys used for Decryption:\n"); 
      System.out.println("Public key n: " + n); 
	       System.out.println("Private key d: " + d); 
   print_key_flag++; 
  } 
   
  return (ciphertext.modPow(d,n)).toString(); 
 } //end decryptText 
    
 /** 
   * Convert the plaintext into it's corresponding byte value. 
   * @param plaintext Plaintext as a string 
  */ 
     public String encodeString(String plaintext){ 
 
    // Go through each character in the plaintext, and convert it to a byte (ascii value) 
    // Then return the big integer representation (as a string) 
      byte array[] = new byte[MAX_LENGTH]; 
  
      for(int i = 0; i < plaintext.length(); i++){ 
        array[15-i] = (byte)plaintext.charAt(i); 
    } 
        String encodedstring = ((new BigInteger(array)).toString());
		 return encodedstring;    
 } //end encodeString 
  
 /** 
   * Convert the ciphertext into it's corresponding plaintext. 
   * @param numerictext ASCII value of encoded text. 
   */    
     public String decodeString(String numerictext) { 
 
    // Create a big integer representation of our string 
      BigInteger biginteger = new BigInteger(numerictext);   
    BigInteger modvalue = new BigInteger("256"); 
    byte array[] = new byte[MAX_LENGTH]; 
    byte newarray[]; 
      int strlen = MAX_LENGTH; 
      
    // Store the byte ascii values into our array 
      for(int i = 0; i < MAX_LENGTH; i++) { 
         array[i] = (byte)(biginteger.mod(modvalue)).intValue(); 
         biginteger = biginteger.divide(modvalue); 
      } 
         while(array[strlen-1] == 0) { 
   strlen--;       
 } 
    // Trim down the array       while(array[strlen-1] == 0) { 
     
    // Copy contents into the newarray and return the string object  
    newarray = new byte[strlen]; 
    for(int i = 0; i < strlen; i++){ 
       newarray[i] = array[i]; 
  } 
  
    // Convert ascii values to a string and return the decoded string    
	   return new String(newarray); 
   }  //end decodeString                      
    
   //NOTE:The string break up logic was used from http://www.cs.colostate.edu/~pfau   
 
 /**  
   * Data members 
  */ 
 private File input,output;   //input & output files 
 private FileReader reader;   //input buffer 
  private FileWriter writer;          //output buffer 
  private BufferedReader buffer;    //input buffer 
  private static StringBuffer s = new StringBuffer(120);  //buffer for name 
  String in  = "input.txt";      //default filenames 
  String out = "encrypt.txt";     
  private String aString = " ";      
  private final int MAX_LENGTH = 16;  //Buffer size   
  private int print_key_flag = 0;    //Print keys 
  }