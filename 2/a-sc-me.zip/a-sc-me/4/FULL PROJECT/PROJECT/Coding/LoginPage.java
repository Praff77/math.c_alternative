/****************************************************************/
/*                      LoginPage	                            */
/*                                                              */
/****************************************************************/
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;
import java.net.*;
import java.io.*;
//import java.lang.Thread;
/**
 * Summary description for LoginPage
 *
 */
public class LoginPage extends JFrame //implements Runnable
{
	// Variables declaration
	private JLabel jLabel1;
	private JLabel jLabel2;
	private JTextField jTextField1;
	private JPasswordField jPasswordField1;
	private JButton jButton1;
	private JButton jButton2;
	private JPanel contentPane;
	public DbConnection db=null;
	 Statement st=null;
	 ResultSet rs=null;
	private int nuser;
	private int uno=1;
	private String sname="";
	// End of variables declaration


	public LoginPage()
	{
		 super();
        
       //  db=new DbConnection();
		// st=db.DBConnect();
         getServerHostName();
		 initializeComponent();
		//
		// TODO: Add any constructor code after initializeComponent call
		//
 
		this.setVisible(true);
	}

	/**
	 * This method is called from within the constructor to initialize the form.
	 * WARNING: Do NOT modify this code. The content of this method is always regenerated
	 * by the Windows Form Designer. Otherwise, retrieving design might not work properly.
	 * Tip: If you must revise this method, please backup this GUI file for JFrameBuilder
	 * to retrieve your design properly in future, before revising this method.
	 */
	private void initializeComponent()
	{
		jLabel1 = new JLabel();
		jLabel2 = new JLabel();
		jTextField1 = new JTextField();
		jPasswordField1 = new JPasswordField();
		jButton1 = new JButton();
		jButton2 = new JButton();
		contentPane = (JPanel)this.getContentPane();

		//
		// jLabel1
		//
		jLabel1.setForeground(new Color(241, 235, 234));
		jLabel1.setText("                     User Login");
		//
		// jLabel2
		//
		jLabel2.setIcon(new ImageIcon("picture\\login1.GIF"));
		jLabel2.setText("jLabel2");
		//
		// jTextField1
		//
		jTextField1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e)
			{
				jTextField1_actionPerformed(e);
			}

		});
		//
		// jPasswordField1
		//
		jPasswordField1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e)
			{
				jPasswordField1_actionPerformed(e);
			}

		});
		//
		// jButton1
		//
		jButton1.setText("OK");
		jButton1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e)
			{
				jButton1_actionPerformed(e);

				//Thread  t=new Thread(this);
	     	    //t.setPriority(9);
		       // t.start();

			}

		});
		//
		// jButton2
		//
		jButton2.setText("CANCEL");
		jButton2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e)
			{
				jButton2_actionPerformed(e);
			}

		});
		//
		// contentPane
		//
		contentPane.setLayout(null);
		addComponent(contentPane, jLabel1, 129,13,194,18);
		
		addComponent(contentPane, jTextField1, 137,109,182,20);
		addComponent(contentPane, jPasswordField1, 137,134,182,19);
		addComponent(contentPane, jButton1, 114,174,101,24);
		addComponent(contentPane, jButton2, 216,174,104,24);
		addComponent(contentPane, jLabel2, -6,-1,471,266);
		//
		// LoginPage
		//
		this.setTitle("LoginPage ");
		this.setLocation(new Point(250, 250));
		this.setSize(new Dimension(473, 298));
	}

	/** Add Component Without a Layout Manager (Absolute Positioning) */
	private void addComponent(Container container,Component c,int x,int y,int width,int height)
	{
		c.setBounds(x,y,width,height);
		container.add(c);
	}

	//
	// TODO: Add any appropriate code in the following Event Handling Methods
	//
	private void jTextField1_actionPerformed(ActionEvent e)
	{
		System.out.println("\njTextField1_actionPerformed(ActionEvent e) called.");
		// TODO: Add any handling code here

	}

	private void jPasswordField1_actionPerformed(ActionEvent e)
	{
		System.out.println("\njPasswordField1_actionPerformed(ActionEvent e) called.");
		// TODO: Add any handling code here

	}

	private void jButton1_actionPerformed(ActionEvent e)
	//public void run()
	{
		//System.out.println("\njButton1_actionPerformed(ActionEvent e) called.");
		// TODO: Add any handling code here
          
		try
		{
			String s1=jTextField1.getText().trim();
			String s2=jPasswordField1.getText().trim();  
 			String scombine=s1+"#"+s2;
			int ch= 0;
			System.out.println("username--"+scombine);
			try
			{
				Socket es11 = new Socket(sname,9876);
				ObjectOutputStream en11 = new ObjectOutputStream(es11.getOutputStream());
				ObjectInputStream en21=new ObjectInputStream(es11.getInputStream());   		
	 	        en11.writeObject("1");
				en11.writeObject("validate");
				en11.writeObject(scombine);
				ch=(Integer)en21.readObject();
				en11.writeObject("");
				en11.writeObject("");
				en11.writeObject("");

				es11.close();
			}
			catch(Exception el)
			{
				el.printStackTrace();
			}
			if(ch != 0)
			{
				System.out.println("LoGIN--"+ch);
				UserOne one=new UserOne(ch);
     			this.setVisible(false);
			}					    
			else
			{
			     JOptionPane.showMessageDialog(this,"Invalid username and password");	     
			}	
		}   
 		catch(Exception ee)
		{
		  System.out.println("error in db");	 
		  ee.printStackTrace();
        }
		finally
 		{
 			jTextField1.setText("");
		    jPasswordField1.setText("");
 		}
	}

	private void jButton2_actionPerformed(ActionEvent e)
	{
		//System.out.println("\njButton2_actionPerformed(ActionEvent e) called.");
		// TODO: Add any handling code here

		jTextField1.setText("");
		jPasswordField1.setText("");

	}

	//
	// TODO: Add any method code to meet your needs in the following area
	//


public void getServerHostName()
	 {

		try
		{

			FileInputStream fis=new FileInputStream("server.txt");
			byte b[]=new byte[fis.available()];
			fis.read(b);
		    sname= new String(b);
			System.out.println("SERVER NAME IS "+sname);

		}

		catch (Exception e)
		{
		}
	
	}
 

//============================= Testing ================================//
//=                                                                    =//
//= The following main method is just for testing this class you built.=//
//= After testing,you may simply delete it.                            =//
//======================================================================//
	public static void main(String[] args)
	{
		JFrame.setDefaultLookAndFeelDecorated(true);
		JDialog.setDefaultLookAndFeelDecorated(true);
		try
		{
			UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
		}
		catch (Exception ex)
		{
			System.out.println("Failed loading L&F: ");
			System.out.println(ex);
		}
		LoginPage lp=new LoginPage();
		//Thread t=new Thread(lp);
	//	t.setPriority(2);
		//t.start();

		//Thread  t=new Thread(lp);
	   // t.setPriority(9);
		//t.start();

	}
//= End of Testing =


}
