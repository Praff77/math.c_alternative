import java.io.*;
import java.math.*;
import java.util.*;
import java.sql.*;

class PrivateKeyGen 
{
	private static Statement st=null;
	private static ResultSet rs=null;
	private static String pub="";
	public static TreeMap tm;
	 static  int tt=0;
	//public static int tkey;
	
	public  RSA rsa=null;
	public PrivateKeyGen()
	{
        tm=new TreeMap();
		 DbConnection dbc=new DbConnection();
         st=dbc.DBConnect();
	}
     public void getMapValue()
	{
	   

             Set s=tm.entrySet();
			 Iterator it=s.iterator();
              while(it.hasNext()) {
              Map.Entry me = (Map.Entry)it.next();
              
               System.out.print("   map key is  "+me.getKey() + ": "); 

               System.out.println("map value is  "+me.getValue());
			  }

	}

     public void getPrivate()
	  {
		try
		{
		  
		  
		   rs=st.executeQuery("select * from publickeytable ");
		   while(rs.next())
			{
			   pub+=rs.getString(2)+"#";
			}
		   System.out.println(pub);
		   String a[]=pub.split("#");
		   
		   for(int i=0,user=1;i<a.length;i++,user++)
			{

		
		    int l=Integer.parseInt(a[i]);
		   if(l%2==1)
				{
		       rsa=new RSA(new BigInteger(a[i]));
                }
				else
				{
							
					l=l+1;
					String ls=Integer.toString(l);
					rsa=new RSA(new BigInteger(ls));
				
				}
		
	     // System.out.println("pub"+rsa.getPublicKey());
         
		// System.out.println("N1"+rsa.getN());

	      BigInteger rss=rsa.getPrivateKey();
		//long l=rs.longValue();
		 //System.out.println("long values is "+l);
		 //BigInteger bi =BigInteger.valueOf(l);
			 //System.out.println("converted from long val "+bi);

             byte[] b2 = rss.toByteArray();
			 System.out.println(" byte values is "+b2);
			 String finalprivate=b2.toString();

			 st.executeUpdate("insert into privatekeytable values('"+user+"','"+finalprivate+"')");
			 System.out.println(" string value of byte is "+finalprivate);
			 
			 String ss=rss.toString();

			 
			 tm.put(user,new BigInteger(ss));

		  //  System.out.println("Big integer values private key "+rs);
			// System.out.println("priv"+rsa.getPrivateKey());
      //   System.out.println("N2"+ rsa.getN());
			 
			}
	
	   }
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}
     public int getFinalKeySize()
	{
		 int eee=0;
		 try
		 {
			ResultSet rq=st.executeQuery("select * from keysize");
            if(rq.next())
			 {
				eee=rq.getInt(1);
			 }
		 }
		 catch (Exception ee2)
		 {
			 ee2.printStackTrace();

		 }
		 return eee;
	}

     public static void main(String arg[])
	  {
	
	
          PrivateKeyGen pkey=new PrivateKeyGen();
		  pkey.getPrivate();
		  
           
		   tt=pkey.getFinalKeySize();
		 
		  System.out.println(" key size for privatekey set "+tt);
		  
		  CreatePrimaryKeySet ks=new CreatePrimaryKeySet();
		  ks.createKeySet(tt);
		  //pkey.getMapValue();
	  }
	
} 
