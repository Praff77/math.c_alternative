import java.net.*;
import java.io.*;
import java.sql.*;
class Server extends Thread
{
	private Statement st=null;
	private int waitClient;
	private String askport="";
	private String portnumber="";
	private String systemName="";
	private String askSystemName="";
	private String datasize="";
	private String cuser="";
	int spint;
	String cone="";
    String sprivset="";
	int row=0;
	
	public Server()
	{
		DbConnection db=new DbConnection();
		st=db.DBConnect();
    }
	public void run()
	{
		try
		{
			ServerSocket ss=new ServerSocket(9876);
			while(true)
			{
				Socket s=ss.accept();
				ObjectInputStream in=new ObjectInputStream(s.getInputStream());
				ObjectOutputStream ots=new ObjectOutputStream(s.getOutputStream());
				new Message();
		 		Object o = in.readObject();
				System.out.println( "Object "+o  );	
				waitClient = Integer.parseInt(o.toString());
		  		
				System.out.println(" The  User which is waiting for port no is "+waitClient);
      	        cone=(String)in.readObject();
				System.out.println("cone:"+cone);

				if(cone.equals("userlist"))
				{
					String getvec=addUserInVector(waitClient);
					ots.writeObject(getvec);
				}
				if(cone.equals("needdestuno"))
				{
					int destuno1=0;
					String sedest=(String)in.readObject();
					System.out.println("in server side uno"+sedest);
					ResultSet rs11=st.executeQuery("select * from login where username='"+sedest+"'");
					while(rs11.next())
					{
						destuno1=rs11.getInt(1);
					}
					String geport=getPort1(destuno1);
					String gesysname=getSystemName(destuno1);
					String com=geport+"#"+gesysname;
					ots.writeObject(com);
				}
				if(cone.equals("getpubkey"))  
				{
					String sedest=(String)in.readObject();
					String receipub=getPublicKey(sedest);
					ots.writeObject(receipub);			 
				}
				if(cone.equals("encryptime"))
				{
					String sedest=(String)in.readObject();
					String senp[]=sedest.split("#");
					int pnokey=Integer.parseInt(senp[0]); 
					String dsi=senp[1];  
					String eti=senp[2];
					st.executeUpdate("insert into timecal values('"+pnokey+"',1024,'"+dsi+"','"+eti+"',0)"); 
				}
	            if(cone.equals("storedecryptime"))
				{
					String sedest=(String)in.readObject();
					String dpriv="";
					ResultSet rq=st.executeQuery("select pu.pkey from publickeytable pu where pu.uno = ( select pr.uno from privatekeytable pr where pr.privkey = '"+sedest+"' )"); 
					if(rq.next())
					{
						dpriv=rq.getString(1);
					}
		            ots.writeObject(dpriv);
					String dectime=(String)in.readObject();
					String adectime[]=dectime.split("#");
					String td3=adectime[0];
					String keno=adectime[1];
					int ieno=Integer.parseInt(keno);
					st.executeUpdate("update timecal set Dectime='"+td3+"' where npkey='"+ieno+"'");
				}
				if(cone.equals("keysize"))
				{
					String keys="";
					ResultSet rs=st.executeQuery("select * from keysize");
				    while(rs.next())
					{
						String pp=rs.getString(1);		 
						int tkey=2+Integer.parseInt(pp);
						String totkey=Integer.toString(tkey);
						keys="2"+"#"+pp+"#"+totkey;
					}
					ots.writeObject(keys);
				}
	            if(cone.equals("timemeasure"))    
				{             
					ResultSet rt=st.executeQuery("select * from timecal");
					while(rt.next())
					{
						row++;
					}
			        String d[][] = new String[row][5];
					int j = 0;
					ResultSet rst = st.executeQuery("select * from timecal");
					while(rst.next())
					{
				        d[j][0] = rst.getString(1);
				        d[j][1] = rst.getString(2);
				        d[j][2] = rst.getString(3);
				        d[j][3] = rst.getString(4);
				        d[j][4] = rst.getString(5);
				         j++;
					}
			        ots.writeObject(d);
				}
				if(cone.equals("validate"))    
				{
					int ch=0;
					String sedest=(String)in.readObject();
					String senp[]=sedest.split("#");
					String user=senp[0];  
					String pass=senp[1];
					System.out.println("user-"+sedest);
					ResultSet rse= st.executeQuery("select * from login where username='"+user+"'AND password1='"+pass+"'");
 	            	if(rse.next())
 					{
 	            	    ch=rse.getInt(1);
					}
					ots.writeObject(ch); 
				}

				sprivset=(String)in.readObject();
				if(sprivset.equals("privkeyset"))
				{
					String lk=getPrivateKeySet(waitClient);
					ots.writeObject(lk);
				}
				askport=(String)in.readObject();
				if(askport.equals("needportno"))
				{
					String gp=getPort1(waitClient);
					ots.writeObject(gp);
				}             
				String uset=(String)in.readObject();
				if(uset.equals("needID"))
				{
					String geuid=getUserSet(waitClient);
					ots.writeObject(geuid);
				} 
			}
			
		}
		catch (Exception el)
		{
		  el.printStackTrace();
		}
	}

	public void getPort()
	{
		try
		{
			ResultSet rs1=st.executeQuery("select * from login where uno='"+waitClient+"'");
			while(rs1.next())
			{
				portnumber=rs1.getString(5);
				System.out.println("portnumber of the User "+waitClient+"is:"+portnumber);		
			}
		}
		catch (Exception ex)
		{
			ex.printStackTrace();
		}
	}

    public String getPort1(int geuno)
	{
		int rgeuno=geuno;
		String portnumber1="";
		try
		{
			ResultSet rs1=st.executeQuery("select * from login where uno='"+rgeuno+"'");
			while(rs1.next())
			{
				portnumber1=rs1.getString(5);
				System.out.println("portnumber of the User "+rgeuno+"is:"+portnumber1);				
			}
		}
		catch (Exception ex)
		{
			ex.printStackTrace();
		}
		return portnumber1;
	}

	public String getSystemName(int gesys)
    { 
		int rsys=gesys; 
		try
		{
			ResultSet rs=st.executeQuery("select * from login where uno='"+rsys+"'");
			while(rs.next())
			{
				systemName=rs.getString(4);			
			}
		}
		catch (Exception ex)
		{
			ex.printStackTrace();
		}
		return systemName;
	}

	public String addUserInVector(int vin)
	{
		int hvin=vin;
		System.out.println("fun "+hvin);
		String vv="";
		int is;
	    try
		{
			ResultSet rse=st.executeQuery("select * from login");
			while(rse.next())
			{
				is=rse.getInt(1);
				if(is!=hvin)
				{
		    		vv+=rse.getString(2)+"#";
				}
				else
					cuser=rse.getString(2);
			}
		}
		catch (Exception ev)
		{
		   ev.printStackTrace();
		}
        System.out.println("vector in server"+vv);
		return vv;
	 }

	private String getPrivateKeySet(int vp)
	{
		int svp=vp;
		String tkey[]=null;
		String plist="";
		try
		{
			ResultSet pset=st.executeQuery("select keysets from privatekeyset where uno='"+svp+"'");
			while(pset.next())
			{
				String se=pset.getString(1);
				tkey=se.split("#");
			}
            for(int w=0;w<tkey.length;w++)
		    {
				plist+=tkey[w]+"#";
			}
		}
		catch (Exception ge)
		{
		   ge.printStackTrace();
		}
		return plist;
	 }

    private String  getPublicKey(String sp)
	{
		String ppkey="";
		String aspget="";
		try
		{
			String gsp=sp;
			String asp[]=gsp.split("#");
	 		for(int w=0;w<asp.length;w++)
		    {
				aspget=asp[w];
				if(aspget.equals(""))
				{
					System.out.println("This is empty");
				}
				else if(aspget.equals("#"))
				{
					System.out.println("This is or pac");
				}
				else
				{
					int spint=Integer.parseInt(aspget,2); 
					System.out.println(" int value of binary is  "+spint);
					ResultSet rs4=st.executeQuery("select pkey from publickeytable where uno='"+spint+"'");
					if(rs4.next())
					{
						ppkey+=rs4.getString(1)+"#";
				    }			    	           		          
				    aspget="";
				}
			 } 
		 }
		 catch (Exception es)
         {
			es.printStackTrace();
		 }
		 return ppkey;
	 }
	
	 public String getUserSet(int rid)
	 {
		 String reID="";
		 int arid=rid;
		 try
		 {  	  
			ResultSet ll=st.executeQuery("select userset from privatekeyset where uno='"+arid+"'");
			if(ll.next())
			{
				reID=ll.getString(1);
			}
		 }
		 catch (Exception eu)
         {
			eu.printStackTrace();
         }
		 return reID;
	}


	public static void main(String[] args) 
	{
		Server ss=new Server();
		ss.start();
	}
}
