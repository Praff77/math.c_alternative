
/****************************************************************/
/*                      ServerHome	                            */
/*                                                              */
/****************************************************************/
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;
import java.util.*;

/**
 * Summary description for ServerHome
 *
 */
public class ServerHome extends JFrame
{
	// Variables declaration
	private JLabel jLabel1;
	private JLabel jLabel2;
	private JLabel jLabel3;
	private JButton jButton1;
	private JButton jButton2;
	private JButton jButton3;
	private JPanel contentPane;
	public String temp;
	public int user;
	public FindKeySize fks;
	private int fk;
    public GenKeys gk;
	private  DbConnection db=null;
	private Statement st=null;
	private ResultSet rs=null;
	// End of variables declaration


	public ServerHome()
	{
		super();
		db=new DbConnection();
		st=db.DBConnect();
		initializeComponent();
		//
		// TODO: Add any constructor code after initializeComponent call
		//

		this.setVisible(true);
	}

	/**
	 * This method is called from within the constructor to initialize the form.
	 * WARNING: Do NOT modify this code. The content of this method is always regenerated
	 * by the Windows Form Designer. Otherwise, retrieving design might not work properly.
	 * Tip: If you must revise this method, please backup this GUI file for JFrameBuilder
	 * to retrieve your design properly in future, before revising this method.
	 */
	private void initializeComponent()
	{
		jLabel1 = new JLabel();
		jLabel2 = new JLabel();
		jLabel3 = new JLabel();
		jButton1 = new JButton();
		jButton2 = new JButton();
		jButton3 = new JButton();
		contentPane = (JPanel)this.getContentPane();

		//
		// jLabel1
		//
		jLabel1.setIcon(new ImageIcon("picture\\key3.JPG"));
		jLabel1.setText(".");
		//
		// jLabel2
		//
		jLabel2.setIcon(new ImageIcon("picture\\serverhome1.PNG"));
		jLabel2.setText("jLabel2");
		//
		// jLabel3
		//
		jLabel3.setForeground(new Color(241, 235, 234));
		jLabel3.setText("                 AUTHENTICATION SERVER");
		//
		// jButton1
		//
		jButton1.setText("USER REGISTRATION");
		jButton1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e)
			{
				jButton1_actionPerformed(e);
			}

		});
		//
		// jButton2
		//
		jButton2.setText("KEY GENERATION");
		jButton2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e)
			{
				jButton2_actionPerformed(e);
			}

		});
		//
		// jButton3
		//
		jButton3.setText("EXIT");
		jButton3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e)
			{
				jButton3_actionPerformed(e);
			}

		});
		//
		// contentPane
		//
		contentPane.setLayout(null);
		
		
		addComponent(contentPane, jLabel3, 90,11,287,27);
		addComponent(contentPane, jButton1, 279,132,157,28);
		addComponent(contentPane, jButton2, 279,202,157,28);
		addComponent(contentPane, jButton3, 280,270,157,28);
		addComponent(contentPane, jLabel1, -30,69,484,291);
		addComponent(contentPane, jLabel2, -48,-52,500,544);
		//
		// ServerHome
		//
		this.setTitle("ServerHome - extends JFrame");
		this.setLocation(new Point(0, 0));
		this.setSize(new Dimension(455, 477));
		new Message();
	}

	/** Add Component Without a Layout Manager (Absolute Positioning) */
	private void addComponent(Container container,Component c,int x,int y,int width,int height)
	{
		c.setBounds(x,y,width,height);
		container.add(c);
	}

	//
	// TODO: Add any appropriate code in the following Event Handling Methods
	//
	private void jButton1_actionPerformed(ActionEvent e)
	{
		//System.out.println("\njButton1_actionPerformed(ActionEvent e) called.");
		// TODO: Add any handling code here

		temp=JOptionPane.showInputDialog(this, "Enter Number of User");
        user=Integer.parseInt(temp);
		new UserRegistrationFinal(user);

	}

	private void jButton2_actionPerformed(ActionEvent e)
	{
		//System.out.println("\njButton2_actionPerformed(ActionEvent e) called.");
		// TODO: Add any handling code here


		try
		{
		
		 fks=new FindKeySize(user);
		 fk=fks.keySize();
		 System.out.println("Final Key size is "+fk);

		
			st.execute("drop table keysize");
			st.execute("create table keysize(keys int)");
			st.executeUpdate("insert into keysize values('"+fk+"')");

		   
		
		/* KeySize ks=new KeySize();
	     ks.setFinalKeySize(fk);*/
		 
		 System.out.println("key size class setted ");
		 //PrivateKeyGen.tkey=fk;
		//System.out.println("\njButton2_actionPerformed(ActionEvent e) called.");
		// TODO: Add any handling code here
        String fpp=generateKeys1(fk);
        StringTokenizer stz=new StringTokenizer(fpp,"#");
		int userno=1;
		while(stz.hasMoreTokens())
		{
           String sk=stz.nextToken();
		   st.executeUpdate("insert into publickeytable values('"+userno+"','"+sk+"')");
          // String np=Integer.toString(userno);
		//   String priv=sk+np;
		
		//   st.executeUpdate("insert into privatekeytable values('"+userno+"','"+priv+"')");
		  userno++;
		}
	  	}
		catch (Exception et)
		{
			et.printStackTrace();
		}


	}

	private void jButton3_actionPerformed(ActionEvent e)
	{
		//System.out.println("\njButton3_actionPerformed(ActionEvent e) called.");
		// TODO: Add any handling code here

		System.exit(0);

	}

	//
	// TODO: Add any method code to meet your needs in the following area
	//




















  public String generateKeys1(int c)
	{
		String keys="";
		gk=new GenKeys();
		for(int i=0;i<c;i++)
		{
			keys=gk.getKeys();
		}
		System.out.println(keys);
		return keys;
	}                  









 

//============================= Testing ================================//
//=                                                                    =//
//= The following main method is just for testing this class you built.=//
//= After testing,you may simply delete it.                            =//
//======================================================================//
	public static void main(String[] args)
	{
		JFrame.setDefaultLookAndFeelDecorated(true);
		JDialog.setDefaultLookAndFeelDecorated(true);
		try
		{
			UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
		}
		catch (Exception ex)
		{
			System.out.println("Failed loading L&F: ");
			System.out.println(ex);
		}
		new ServerHome();
	}
//= End of Testing =


}
