	
 /****************************************************************/ 
 /*                      dha	                            */ 
 /*                                                              */ 
 /****************************************************************/ 
 import java.awt.*; 
 import java.awt.event.*; 
 import javax.swing.*; 
 import java.sql.*;
 import java.net.*;
 import java.util.*;
 import java.io.*;
 import java.math.*;
 import javax.swing.table.*; 
 /** 
  * Summary description for dha 
  * 
  */ 
 public class UserOne extends JFrame implements Runnable
 { 
 	// Variables declaration 
 	private JLabel jLabel1;
	private JLabel jLabel2;
	private JLabel jLabel3;
	private JLabel jLabel4;
	private JLabel jLabel5;
 	private JTextField jTextField1; 
 	private JComboBox jComboBox1; 
	private JComboBox jComboBox2; 
	private JComboBox jComboBox3;
 	private JTextArea jTextArea1; 
 	private JScrollPane jScrollPane1; 
 	private JTextArea jTextArea2; 
 	private JScrollPane jScrollPane2; 
 	private JButton jButton1; 
 	private JButton jButton2; 
 	private JButton jButton3; 
	private JButton jButton4; 
 	private JPanel contentPane; 
	private Statement st=null;
	private ResultSet rs=null;
	private ResultSet pset=null;
	private Vector des;
	private Vector keyset=null;
    private Vector pubkey=null;
	private String cuser="";
	private int is;
	private String sname="";

	private int msg=0;

	private String receivePort="";
	private int clientServerSocket;
	private int destuno,destuno1;
	private String sdest;
	private String dsname="";
	private String dst="";
	private String msgg="";
	private RSA  rsa=null;
	private String fileEcrypt="filename.txt";
	
	private ArrayList al=null;
	private int first=1;
	private String defile="encrypt.txt";
	private int inn=1;
	private JScrollPane jScrollPane3;
	
	private String DataSize="";
	int kkk=1;
	ButtonGroup buttonGroup;
	JRadioButton MTable,Chart;
	private JTable jTable1;
	int kkk1=1;
	
	private String idSET="";
	String sdest1="";
	String destsystem="";
 	
  public UserOne(int primary)
  {
        super();    
        msg = primary;
		sname = getServerHostName();
		Thread t1=new Thread(this);
	    t1.setPriority(10);
		t1.start();
 		initializeComponent();     
	    
		
  }

public void run()
{
    keyset=new Vector();
    String tkey[]=null;
	String resID=""; 
	des=new Vector();
	try
	{	
		if(true)
		{
			 System.out.println("sessesese  === "+sname);				
			 Socket s = new Socket(sname,9876);		
			 ObjectOutputStream ots = new ObjectOutputStream(s.getOutputStream());
			 ots.writeObject(msg);
			 
			 System.out.println(" Sending node name is "+msg);
			 ots.writeObject("userlist");
			 
			 ObjectInputStream in=new ObjectInputStream(s.getInputStream());
			 String gevecser=(String)in.readObject();
			 System.out.println("vector values in one "+gevecser);
			 String agevecser[]=gevecser.split("#");
			 for(int w=0;w<agevecser.length;w++)
			 {
				 des.add(agevecser[w]);
			 }
			 ots.writeObject("privkeyset"); 
			 String se=(String)in.readObject();
			 System.out.println("private key set "+se);
			 tkey=se.split("#");   
			 String plist="";
			 for(int w=0;w<tkey.length;w++)
			 {   
			   keyset.add(tkey[w]);
			 }
			 ots.writeObject("needportno");     
			 receivePort=(String)in.readObject();
			 System.out.println("PORT NUMBER OF THE USER :"+msg+"IS:"+receivePort);
			 clientServerSocket=Integer.parseInt(receivePort);
			 ots.writeObject("needID"); 
			 idSET=(String)in.readObject();
			 String areID[]=idSET.split(",");
			 for(int t=0;t<areID.length;t++)
			 {
				String sid=areID[t];
				int isid=Integer.parseInt(sid);    
				System.out.println(" spilit int "+isid);
				String by = Integer.toBinaryString(isid);
				resID+=by+"#";
			 }
			 System.out.println("Private key set binary values is  "+resID);
			  s.close();

			 ServerSocket cs=new ServerSocket(clientServerSocket);
			 while(true)
			 {
				 Socket ca=cs.accept();
				 ObjectOutputStream dos1=new ObjectOutputStream(ca.getOutputStream());
				 ObjectInputStream din=new ObjectInputStream(ca.getInputStream());		
				 String remsg=(String)din.readObject();
				 jTextArea1.setText(remsg);
				 String sendID=(String)din.readObject();
				 if(sendID.equals("needID"))
				 {
					JOptionPane.showMessageDialog(this,"some user asking id. Can you proceed ? ");
					dos1.writeObject(resID);
				 }
				 if(sendID.equals("cont"))
				 {
					String ori=(String)din.readObject();
					BufferedWriter writer1 = new BufferedWriter(new FileWriter("original2.txt"));
					writer1.write(ori);
					writer1.flush();
					writer1.close();	
					String ori1=(String)din.readObject();
					BufferedWriter writer2 = new BufferedWriter(new FileWriter("encry.txt"));
					writer2.write(ori1);
					writer2.flush();
					writer2.close();		 
				 }
			}			 
	  }
	}
    catch(Exception eh)
	{
		 eh.printStackTrace();
	}
}
 	public void initializeComponent() 
 	{ 
 		jLabel1 = new JLabel(); 
		jLabel2 = new JLabel();
		jLabel3 = new JLabel();
		jLabel4 = new JLabel();
		jLabel5 = new JLabel();
 		jTextField1 = new JTextField(); 
 		jComboBox1 = new JComboBox(keyset); 
		jComboBox2 = new JComboBox(des);
		jComboBox3 = new JComboBox();
 		jTextArea1 = new JTextArea(); 
 		jScrollPane1 = new JScrollPane(); 
 		jTextArea2 = new JTextArea(); 
 		jScrollPane2 = new JScrollPane(); 
 		jButton1 = new JButton(); 
 		jButton2 = new JButton(); 
 		jButton3 = new JButton(); 
		jButton4 = new JButton();
		 
		jScrollPane3 = new JScrollPane(); 
		buttonGroup = new ButtonGroup();
		MTable=new JRadioButton();
	    Chart=new JRadioButton();
		buttonGroup.add(MTable);
		buttonGroup.add(Chart);
		jTable1 = new JTable(); 

		pubkey=new Vector();
		
 		contentPane = (JPanel)this.getContentPane(); 
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
 		// 
 		// jLabel1 
 		// 
 		jLabel1.setIcon(new ImageIcon("picture\\DHA.PNG")); 
 		jLabel1.setText("jLabel1"); 
		
		jLabel2.setForeground(new Color(241, 235, 234));
		jLabel2.setText("    SMOCK USER  "+cuser);
		


		jLabel3.setText("Public key:");
		jLabel3.setForeground(new Color(232, 17, 17)); 
		
		jLabel4.setText("Private-key set");
		jLabel4.setForeground(new Color(232, 17, 17)); 

		jLabel5.setText("Destination User");
		jLabel5.setForeground(new Color(232, 17, 17)); 
 		// 
 		// jTextField1 
 		// 

         jTable1.setModel(new DefaultTableModel(5, 5));

 		jTextField1.addActionListener(new ActionListener() { 
 			public void actionPerformed(ActionEvent e) 
 			{ 
 				jTextField1_actionPerformed(e); 
 			} 
  
 		}); 
 		// 
 		// jComboBox1 
 		// 
 		jComboBox1.addActionListener(new ActionListener() { 
 			public void actionPerformed(ActionEvent e) 
 			{ 
 				jComboBox1_actionPerformed(e); 
 			} 
  
 		}); 
		jComboBox2.addActionListener(new ActionListener() { 
 			public void actionPerformed(ActionEvent e) 
 			{ 
 				jComboBox2_actionPerformed(e); 
 			} 
  
 		}); 
		jComboBox3.addActionListener(new ActionListener() { 
 			public void actionPerformed(ActionEvent e) 
 			{ 
 				jComboBox3_actionPerformed(e); 
 			} 
  
 		}); 
 		// 
 		// jTextArea1 
 		// 
 		// 
 		// jScrollPane1 
 		// 
       

 		jScrollPane1.setViewportView(jTextArea1); 
 		// 
 		// jTextArea2 
 		// 
 		// 
 		// jScrollPane2 
 		// 
 		jScrollPane2.setViewportView(jTextArea2); 
 		// 
 		// jButton1 
 		// 
 		jButton1.setText("ENCRYPT"); 
 		jButton1.addActionListener(new ActionListener() { 
 			public void actionPerformed(ActionEvent e) 
 			{ 
 				jButton1_actionPerformed(e); 
 			} 
  
 		}); 
 		// 
 		// jButton2 
 		// 
 		jButton2.setText("SEND"); 
 		jButton2.addActionListener(new ActionListener() { 
 			public void actionPerformed(ActionEvent e) 
 			{ 
 				jButton2_actionPerformed(e); 
 			} 
  
 		}); 
 		// 
 		// jButton3 
 		// 
 		jButton3.setText("DECRYPT"); 
 		jButton3.addActionListener(new ActionListener() { 
 			public void actionPerformed(ActionEvent e) 
 			{ 
 				jButton3_actionPerformed(e); 
 			} 
  
 		}); 


		jButton4.setText("EXIT"); 
 		jButton4.addActionListener(new ActionListener() { 
 			public void actionPerformed(ActionEvent e) 
 			{ 
 				jButton4_actionPerformed(e); 
 			} 
  
 		}); 
     

        MTable.setActionCommand("time");
 		MTable.setBackground(new Color(255, 255, 255)); 
 		
 		MTable.setText("MTime"); 
 		
	   MTable.addItemListener(new ItemListener() { 
 			public void itemStateChanged(ItemEvent e) 
 			{ 
 				
				mtable_itemStateChanged(e); 
 			} 
  
 		}); 


          Chart.setActionCommand("chart");
 		Chart.setBackground(new Color(255, 255, 255)); 
 		
 		Chart.setText("Chart"); 
 		
          Chart.addItemListener(new ItemListener() { 
 			public void itemStateChanged(ItemEvent e) 
 			{ 
 				
				Chart_itemStateChanged(e); 
 			} 
  
 		});





 		// 
 		// contentPane 
 		// 
 		contentPane.setLayout(null); 
 		addComponent(contentPane, jLabel2, 70,20,130,18); 
		addComponent(contentPane, jLabel3, 19,93,98,18);
		addComponent(contentPane, jLabel4, 187,93,98,18); 
		addComponent(contentPane, jLabel5, 19,55,98,18);
 		//addComponent(contentPane, jTextField1, 20,114,100,22); 
		addComponent(contentPane, jComboBox3, 20,114,100,22); 
 		addComponent(contentPane, jComboBox1, 183,114,100,22);
		addComponent(contentPane, jComboBox2, 181,53,100,22); 
 		addComponent(contentPane, jScrollPane1, 159,156,138,165); 
 		addComponent(contentPane, jScrollPane2, 15,158,139,164); 
 		addComponent(contentPane, jButton1, 20,363,83,28); 
 		addComponent(contentPane, jButton2, 117,363,83,28); 
 		addComponent(contentPane, jButton3, 210,363,83,28); 
		addComponent(contentPane, jButton4, 116,409,83,28);
		addComponent(contentPane, MTable, 240,400,60,15);
        addComponent(contentPane, Chart, 240,419,60,15); 
		//addComponent(contentPane,jScrollPane3, 250,430,100,111);
		addComponent(contentPane, jLabel1, -6,-24,321,480);
 		// 
 		// dha 
 		// 
 		this.setTitle(+msg+" User JFrame"); 
 		this.setLocation(new Point(0, 0)); 
 		this.setSize(new Dimension(321, 481)); 
		this.setVisible(true);
 	} 

  
 	/** Add Component Without a Layout Manager (Absolute Positioning) */ 
 	private void addComponent(Container container,Component c,int x,int y,int width,int height) 
 	{ 
 		c.setBounds(x,y,width,height); 
 		container.add(c); 
 	} 
  
 	// 
 	// TODO: Add any appropriate code in the following Event Handling Methods 
 	// 
 	private void jTextField1_actionPerformed(ActionEvent e) 
 	{ 
 		System.out.println("\njTextField1_actionPerformed(ActionEvent e) called."); 
 		// TODO: Add any handling code here 
  
 	} 
  
 	private void jComboBox1_actionPerformed(ActionEvent e) 
 	{ 
 		System.out.println("\njComboBox1_actionPerformed(ActionEvent e) called."); 
 		 
 		Object o = jComboBox1.getSelectedItem(); 
 		System.out.println(">>" + ((o==null)? "null" : o.toString()) + " is selected."); 
 		// TODO: Add any handling code here for the particular object being selected 
 		 
 	} 
  private void jComboBox2_actionPerformed(ActionEvent e) 
 	{ 
 		System.out.println("\njComboBox2_actionPerformed(ActionEvent e) called."); 
 		Object o = jComboBox2.getSelectedItem(); 
 		String destuser=o.toString();
		String receiveID="";
		System.out.println(">>" + ((o==null)? "null" : o.toString()) + " is selected."); 
 		JOptionPane.showMessageDialog(this,"Request to User ID");
		 try
         {
			System.out.println("This is listing");
			Socket es1 = new Socket(sname,9876);
            System.out.println("This is listing");
			ObjectOutputStream en1 = new ObjectOutputStream(es1.getOutputStream());
		    ObjectInputStream en2=new ObjectInputStream(es1.getInputStream());
			System.out.println("This is listing");      		
	 		String ssm="1";
			en1.writeObject(ssm);
		  	en1.writeObject("needdestuno");
            en1.writeObject(destuser);
			String rcom=(String)en2.readObject();
			         
			System.out.println("por and sys"+rcom);
			String arcom[]=rcom.split("#");
            sdest1=arcom[0];
			destsystem=arcom[1];
			en1.writeObject("");
			en1.writeObject("");
			en1.writeObject("");
		    en1.close();
			en2.close();
			es1.close();
		 }

	 catch(Exception ese)
		{
			 ese.printStackTrace();
		}

			try
			{
				int css=Integer.parseInt(sdest1);
				Socket s8=new Socket(destsystem,css);
			    ObjectOutputStream dos9=new ObjectOutputStream(s8.getOutputStream());
				ObjectInputStream din9=new ObjectInputStream(s8.getInputStream());
				dos9.writeObject("");
				dos9.writeObject("needID");
				System.out.println("Request for id");
				receiveID=(String)din9.readObject();
				JOptionPane.showMessageDialog(this," ID from user is "+receiveID);
				s8.close();
			}
			catch (Exception e3)
			{
				e3.printStackTrace();
			}
		
 	

	     try
         {			
			Socket es11 = new Socket(sname,9876);
			ObjectOutputStream en11 = new ObjectOutputStream(es11.getOutputStream());
		    ObjectInputStream en21=new ObjectInputStream(es11.getInputStream());    		
	 		en11.writeObject("1");
            en11.writeObject("getpubkey");
            en11.writeObject(receiveID);
            String cryptopublic=(String)en21.readObject();
	        System.out.println(" This is public key from function "+cryptopublic);
	        String apubkey[]=cryptopublic.split("#");
		    jComboBox3.removeAllItems();
			for(int ea=0;ea<apubkey.length;ea++)
			{
					  jComboBox3.addItem(apubkey[ea]);
			}
            en11.writeObject("");
			en11.writeObject("");
			en11.writeObject("");
		    es11.close();
		 }
		 catch(Exception ep)
		{
			 ep.printStackTrace();
		}
	
	} 

     private void jComboBox3_actionPerformed(ActionEvent e) 
 	{ 
 		System.out.println("\njComboBox3_actionPerformed(ActionEvent e) called."); 
 		 
 		Object o = jComboBox3.getSelectedItem(); 
 		System.out.println(">>" + ((o==null)? "null" : o.toString()) + " is selected."); 
 		// TODO: Add any handling code here for the particular object being selected 
 		 
 	} 

          //Encryption 

 	private void jButton1_actionPerformed(ActionEvent e) 
 	{ 
 		
		double d1=System.currentTimeMillis();
		try
		{
         String selectedPubKey=(String)jComboBox3.getSelectedItem();
		  int l=Integer.parseInt(selectedPubKey);
		   if(l%2==1)
			{
		         String tos=Integer.toString(l);       
				rsa=new RSA(new BigInteger(tos));
             }
			else
			{	
					l=l+1;
					String ls=Integer.toString(l);
					rsa=new RSA(new BigInteger(ls));
				}
	       
		
			String sget=jTextArea2.getText();
			BigInteger rss=rsa.getPublicKey();
			String ss=rss.toString();
			BigInteger rss1=rsa.getN();
            String ss1=rss1.toString();
			 if(first==1)
			{
			  BufferedWriter writer1 = new BufferedWriter(new FileWriter("original.txt"));
              writer1.write(sget);
			  writer1.flush();
              writer1.close();
			 first++;
			}

             BufferedWriter writer = new BufferedWriter(new FileWriter("filename.txt"));
             writer.write(sget);
			 writer.flush();
             writer.close();
			
			//DataSize=getBytes(sget);
			
			byte ds=(byte)sget.length();
			DataSize=Byte.toString(ds);
			Encrypt encrypt = new Encrypt(fileEcrypt,ss, ss1);



            FileInputStream fis=new FileInputStream("encrypt.txt");
			byte b[]=new byte[fis.available()];
			fis.read(b);
		    String content= new String(b);
			
            jTextArea2.setText("");
			jTextArea2.setText(content);
            
           
            double d2=System.currentTimeMillis();
			 

            double d3=d2-d1;
			String td3=Double.toString(d3);
	        String skk=Integer.toString(kkk);
			String comtime=skk+"#"+DataSize+"#"+td3;
			 try
			 {	
				System.out.println("sssssssssss -- -  "+sname);
				Socket es = new Socket(sname,9876);
				ObjectOutputStream en = new ObjectOutputStream(es.getOutputStream());
				en.writeObject("1");
				 System.out.println("eddddd encry time");
				 en.writeObject("encryptime");
				 en.writeObject(comtime);
				 en.writeObject("");
				 en.writeObject("");
				 en.writeObject("");
                 es.close();
				  System.out.println("end");
			 }
			 catch (Exception ppp)
			 {
				 ppp.printStackTrace();
			 }
					kkk++;
			 }
		catch (Exception eenc)
		{

			eenc.printStackTrace();
		}
	
	
	} 
	// send button
  
 	private void jButton2_actionPerformed(ActionEvent e) 
 	{ 
 		
			msgg=jTextArea2.getText();
			try
			{
				int css=Integer.parseInt(sdest1);
				Socket s8=new Socket(destsystem,css);
			    ObjectOutputStream dos9=new ObjectOutputStream(s8.getOutputStream());
				  dos9.writeObject(msgg);
				// System.out.println("content before send "+msgg);
				 JOptionPane.showMessageDialog(this,"Successfully Send the Message");
				  System.out.println("  Successfully send");
			      dos9.writeObject("cont");
				  FileInputStream fis1=new FileInputStream("original.txt");
			      byte b1[]=new byte[fis1.available()];
			      fis1.read(b1);
		          String content1= new String(b1);
				  //fis1.flush();
				  fis1.close();
				  dos9.writeObject(content1);
				  // System.out.println("content for before original "+content1);
				 
				  
				 
				  
				  
				  
				  FileInputStream fis11 = new FileInputStream("filename.txt");
			      byte b11[]=new byte[fis11.available()];
			      fis11.read(b11);
		          String content11= new String(b11);
				  
				//  System.out.println("content for before filename "+content11);
				  dos9.writeObject(content11);
                  


				  s8.close();
				  fis11.close();
			}
			catch (Exception e3)
			{
				e3.printStackTrace();
			}
	     
	}
  
 	private void jButton3_actionPerformed(ActionEvent e) 
 	{ 
 		try
		{
			double d1=System.currentTimeMillis();

	       String dpriv="";
           String selectedPrivKey=(String)jComboBox1.getSelectedItem();
 	      
           	 System.out.println("sssssssssss -- -  "+sname);
           Socket es13111 = new Socket(sname,9876);
	        ObjectOutputStream en13111 = new ObjectOutputStream(es13111.getOutputStream());
	        ObjectInputStream en23111=new ObjectInputStream(es13111.getInputStream());
	        en13111.writeObject("1");
		    en13111.writeObject("storedecryptime");
	        en13111.writeObject(selectedPrivKey);
					 
			 dpriv=(String)en23111.readObject();
			 System.out.println("This is decryption"+dpriv);
			          

            int l=Integer.parseInt(dpriv);
		     if(l%2==1)
				{
		         String tos=Integer.toString(l);       
			     rsa=new RSA(new BigInteger(tos));
                }
				else
				{
							
					l=l+1;
					String ls=Integer.toString(l);
					rsa=new RSA(new BigInteger(ls));
				
				}


			BigInteger rss=rsa.getPrivateKey();
			String ss=rss.toString();
			BigInteger rss1=rsa.getN();
            String ss1=rss1.toString();
			

     

             if(inn==1)
			{
				String sget=jTextArea1.getText();
				BufferedWriter writer1 = new BufferedWriter(new FileWriter("encrypt.txt"));
                writer1.write(sget);
		        writer1.flush();
                writer1.close();

            }

           if(inn==2)
			{
		    
			FileInputStream fis1=new FileInputStream("encry.txt");
			byte b3[]=new byte[fis1.available()];
			fis1.read(b3);
		    String content3= new String(b3);
			
					
			//String sget=jTextArea1.getText();
		   	BufferedWriter writer1 = new BufferedWriter(new FileWriter("encrypt.txt"));
            writer1.write(content3);
		    writer1.flush();
            writer1.close();
			}




			
			
			Decrypt decrypt = new Decrypt(defile,ss, ss1);
			
			double d2=System.currentTimeMillis();
			 

            double d3=d2-d1;
			String td3=Double.toString(d3);
			
			
			if(kkk1==1)
			{
			//en13111.writeUTF("writedectime");
              String skkk1=Integer.toString(kkk1);
			 String comtd3=td3+"#"+skkk1;
			  en13111.writeObject(comtd3);
			  en13111.writeObject("");
			  en13111.writeObject("");
			  en13111.writeObject("");

			//st.executeUpdate("update timecal set Dectime='"+td3+"' where npkey=1");
			}
             else
			{
			  //en13111.writeUTF("writedectime");

			 String skkk1=Integer.toString(kkk1);
			 String comtd3=td3+"#"+skkk1;
			  en13111.writeObject(comtd3);
			  en13111.writeObject("");
			  en13111.writeObject("");
			  en13111.writeObject("");

            // st.executeUpdate("update timecal set Dectime='"+td3+"' where npkey=2");
			}
			/*en13111.writeUTF("");
			en13111.writeUTF("");*/
             
            if(inn==2)
			{
			FileInputStream fis1=new FileInputStream("original2.txt");
			byte b1[]=new byte[fis1.available()];
			fis1.read(b1);
		    String content1= new String(b1);
			
            jTextArea1.setText("");
			jTextArea1.setText(content1);
			}
			else
			{
         

			FileInputStream fis=new FileInputStream("decrypt.txt");
			byte b[]=new byte[fis.available()];
			fis.read(b);
		    String content= new String(b);
			
            jTextArea1.setText("");
			jTextArea1.setText(content);
			}
	       
		   
		   inn++;
		   kkk1++;
		 

		 es13111.close();
		}
		catch (Exception ed)
		{
			ed.printStackTrace();
		}
  
  
 	} 

	private void jButton4_actionPerformed(ActionEvent e) 
 	{ 
 		System.out.println("\njButton4_actionPerformed(ActionEvent e) called."); 
 		// TODO: Add any handling code here 
         System.exit(0);
 	} 
private void mtable_itemStateChanged(ItemEvent e) 
 	{ 
       
 		//System.out.println(">>" + ((e.getStateChange() == ItemEvent.SELECTED) ? "selected":"unselected")); 
 		// TODO: Add any handling code here 
          //String select;
		System.out.println("mtable selected");
		if(e.getStateChange()==1)
		{
		
			new CreateTimeMeasure();
		}
			
	}


   
private void Chart_itemStateChanged(ItemEvent e) 
 	{ 

 		 
	
		
		//System.out.println(">>" + ((e.getStateChange() == ItemEvent.SELECTED) ? "selected":"unselected")); 
      
     	if(e.getStateChange()==1)  
		{
 	      
		  
          BarChartDemo demo = new BarChartDemo("Bar Chart for Key Storage");
          demo.pack();
         demo.setVisible(true);
	      
		}
	   
	}
	
 	// 
 	// TODO: Add any method code to meet your needs in the following area 
 	// 
  
  
  
  
  

  
  
  
 
  
  
  
  
  


  
  
  public String getServerHostName()
{
	  String sna ="";
		try
		{

			FileInputStream fis=new FileInputStream("server.txt");
			byte b[]=new byte[fis.available()];
			fis.read(b);
		    sna= new String(b);
			System.out.println("SERVER NAME IS "+sna);
		}
		catch (Exception e)
		{
		}
		return sna;
	}
  
  
  
  
  
  
   
  
 //============================= Testing ================================// 
 //=                                                                    =// 
 //= The following main method is just for testing this class you built.=// 
 //= After testing,you may simply delete it.                            =// 
 //======================================================================// 
 	public static void main(String[] args) 
 	{ 
 		JFrame.setDefaultLookAndFeelDecorated(true); 
 		JDialog.setDefaultLookAndFeelDecorated(true); 
 		try 
 		{ 
 			UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel"); 
 		} 
 		catch (Exception ex) 
 		{ 
 			System.out.println("Failed loading L&F: "); 
 			System.out.println(ex); 
 		} 
 		UserOne x=new UserOne(1);	
 	} 
 } 
  
 