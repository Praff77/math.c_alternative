import java.math.*; 
 
/** 
 * <p>Title:Class Encrypt</p> 
 * <p>Description: This class encrypts a plaintext with the given  
 * public keys. (d,n) </p> 
 * <p>Author: Radhika Reddy</p> 
 */ 
public class Encrypt { 
  
   
 /** 
   * Default Class Constructor. 
   * Uses predefined public keys. 
  */ 
 public Encrypt(){ 
   
  /** 
     * Following keys were generated at 
http://crypto.cs.mcgill.ca/~crepeau/RSA/generator_frame.html 
   */ 
  publickey_e = new 
BigInteger("61404965926479355855905591146111446036174180344042322260881284389185001535129");  
  publickey_n = new BigInteger("87804687216282445014344449262787492088471510759278970766557708167685450735849"); 
  doEncryption(); 
 } 
  
 /** 
   * Class Constructor with keys provided. 
   * This method takes two parameters (public keys e and n) 
   * and encrypts the plaintext stored by default in file "input.txt" 
   * The default file with the ciphertext is "encrypt.txt". 
   * @param e public key 
   * @param n public key 
  */    
  public Encrypt(BigInteger e, BigInteger n){ 
 
    //set the public keys based on input 
  publickey_e = e; 
  publickey_n = n;    
  doEncryption(); 
 } 
  
 /**  
   * Class Constructor with keys and input filename provided. 
   * This method takes three parameters (input filepath, and  
   * public keys e and n). It encrypts the input text using the  
   * keys and writes the output to file "encrypt.txt". 
   * @param filename Input/Plaintext filepath 
   * @param e public key 
   * @param n public key 
  */ 
  public Encrypt(String filename, String e, String n){ 
 
    //set the public keys based on input 
  publickey_e = new BigInteger(e); 
    publickey_n = new BigInteger(n); 
   
  plaintxt = filename;  
   
  doEncryption(); 
 } 
 
 /** 
   * This method performs the main actions of calling the IO class 
   * and encrypting the plaintext 
  */ 
  public void doEncryption(){    
  //perform IO 
     IO io = new IO(plaintxt,ciphertxt);   
         
    //read the plaintext file         
      io.openPlaintext(); 
 
       String temp_str = new String(); 
          
    //read each line of plaintext and encode it with the keys provided          
     while( (temp_str = io.nextLine()) != null){ 
 
      //use 16 character chunks to encode data 
      int chunks = (temp_str.length()/16) + 1;         
         String arr[] = io.breakUpString(temp_str,chunks);   
 
    
      // For each block, encrypt the message    
	  for(int i = 0; i < arr.length; i++){            
    BigInteger ascii_val = new 
BigInteger(io.encodeString(arr[i])); 
 
    //write encoded text to file "encrypt.txt" 
   
 io.writeCipher(io.encryptText(ascii_val,publickey_e,publickey_n)); 
   } 
  } 
   io.closeFile();   //close output file 
 } //end doEncryption 
  
 /** 
   * Main function to run the Encryption program directly 
  */ 
  public static void main (String args[]) { 
   
  int len; 
     len = args.length; 
   
     if(len != 3){ 
       System.out.println("No arguments provided. Default keys and files will be used."); 
       System.out.println("Command format is <Encrypt plaintext publickey_e publickey_n"); 
    Encrypt encrypt = new Encrypt();     
   } 
   else { 
       Encrypt encrypt = new Encrypt(args[0], args[1], args[2]); 
 //user input 
   } 
 } //end main 
 
 /*  
   * Data Members 
  */  
  private BigInteger publickey_e; 
  private BigInteger publickey_n; 
  //default filenames for ciphertext and final output     
  private String plaintxt = "input.txt"; 
  private String ciphertxt = "encrypt.txt"; 
  
}  //end class Encrypt