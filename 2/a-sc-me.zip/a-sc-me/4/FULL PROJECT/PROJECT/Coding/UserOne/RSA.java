import java.math.BigInteger; 
import java.security.SecureRandom; 
     
/** 
 * <p>Title:Class RSA</p> 
 * <p>Description: This class randomly generates public and private 
 * kyes that can be used to encrypt and decrypt text. I use an arbitrary prime 
 * number 70001 as my 'e' value  </p> 
 * <p>Author: Radhika Reddy</p> 
 */ 
public class RSA { 
  

 
 
         



 /** 
   * Class Constructor. 
   * This method randomly generates p and q and uses  
   * e (assumed as prime number 70001) to determine the private keys d and public 
key n. 
  */ 
 public RSA(BigInteger MY_E){ 
   
    System.out.println("Please be patient, the program takes a few minutes to run. . .\n"); 
   /** 
     * Data memebers 
   */

  
   
      

       BigInteger gcd; 
        
       BigInteger p = BigInteger.probablePrime(KEY_SIZE, RANDOM1); 
      BigInteger q = BigInteger.probablePrime(KEY_SIZE, RANDOM2); 
      BigInteger phi = (p.subtract(INT_ONE)).multiply(q.subtract(INT_ONE)); 
   
      publickey_n    = p.multiply(q);                                   
      BigInteger my_public_key = MY_E; 
 
    /* Make sure that the chose value for e is relatively prime with phi.  
     * Otherwise, increment e by 2 till we find 
     * a relatively prime number. 
   */ 
   //System.out.println("inside the while loop");
 
   while( !(gcd = my_public_key.gcd(phi)).equals(INT_ONE)){ 
        my_public_key = my_public_key.add(INT_TWO); 
      }         
      //set the public and private keys. 
      publickey_e = my_public_key;             
      privatekey_d = publickey_e.modInverse(phi); 
   
 } 
    
   /** 
    * Get method to return Private key d - for decryption routine. 
    * @return BigInteger containing the private key 
    */ 
     public BigInteger getPrivateKey(){ 
       return this.privatekey_d; 
     } 
    
   /** 
    * Get method to return Public key e - for encryption routine. 
    * @return BigInteger containing the public key 
    */    
     public BigInteger getPublicKey(){ 
       return this.publickey_e; 
     } 
    
   /** 
    * Get method to return Public key n - for decryption and encryption 
    * routines. 
    * @return BigInteger containing the public key 
    */    
     public BigInteger getN(){ 
       return this.publickey_n; 
     } 
 
 /**  
   * Data members 
  */ 
	
 private final static BigInteger INT_ONE       = new BigInteger("1"); 
  private final static BigInteger INT_TWO      = new BigInteger("2"); 
  private final static SecureRandom RANDOM1     = new SecureRandom(); 
  private final static SecureRandom RANDOM2     = new SecureRandom(); 
  //private final static BigInteger MY_E     = new BigInteger("70001"); 
  private final static  int KEY_SIZE =1024;
  
  private BigInteger privatekey_d; 
  private BigInteger publickey_e; 
  private BigInteger publickey_n; 
         
/*public static void main(String arg[])
	 {
	RSA z=new RSA();
	System.out.println("public  "+z.getN());
	System.out.println("private  "+z.getPrivateKey());
	 }*/

}  //end class RSA