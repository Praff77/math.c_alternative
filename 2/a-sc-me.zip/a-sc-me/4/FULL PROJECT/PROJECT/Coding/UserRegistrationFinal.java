/****************************************************************/
/*                      UserRegistrationFinal	                            */
/*                                                              */
/****************************************************************/
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;
/**
 * Summary description for UserRegistrationFinal
 *
 */
public class UserRegistrationFinal extends JFrame
{
	// Variables declaration
	private JLabel jLabel1;
	private JLabel jLabel2;
	private JLabel jLabel3;
	private JLabel jLabel4;
	private JLabel jLabel5;
	private JLabel jLabel6;
	private JTextField jTextField1;
	private JTextField jTextField2;
	private JTextField jTextField3;
	private JPasswordField jPasswordField1;
	private JButton jButton1;
	private JButton jButton2;
	private JPanel contentPane;
	private  DbConnection db=null;
	private Statement st=null;
	private ResultSet rs=null;
	private int nuser;
	private int uno=1;
	// End of variables declaration


	public UserRegistrationFinal(int u)
	{
		super();
		nuser=u;
		db=new DbConnection();
		st=db.DBConnect();
		initializeComponent();
		//
		// TODO: Add any constructor code after initializeComponent call
		//

		this.setVisible(true);
	}

	/**
	 * This method is called from within the constructor to initialize the form.
	 * WARNING: Do NOT modify this code. The content of this method is always regenerated
	 * by the Windows Form Designer. Otherwise, retrieving design might not work properly.
	 * Tip: If you must revise this method, please backup this GUI file for JFrameBuilder
	 * to retrieve your design properly in future, before revising this method.
	 */
	private void initializeComponent()
	{
		jLabel1 = new JLabel();
		jLabel2 = new JLabel();
		jLabel3 = new JLabel();
		jLabel4 = new JLabel();
		jLabel5 = new JLabel();
		jLabel6 = new JLabel();
		jTextField1 = new JTextField();
		jTextField2 = new JTextField();
		jTextField3 = new JTextField();
		jPasswordField1 = new JPasswordField();
		jButton1 = new JButton();
		jButton2 = new JButton();
		contentPane = (JPanel)this.getContentPane();

		//
		// jLabel1
		//
		jLabel1.setText("                             USER REGISTRATION");
		//
		// jLabel2
		//
		jLabel2.setText("User Name");
		//
		// jLabel3
		//
		jLabel3.setText("Password");
		//
		// jLabel4
		//
		jLabel4.setText("System Name");
		//
		// jLabel5
		//
		jLabel5.setText("Port No");

		jLabel6.setIcon(new ImageIcon("picture\\Regist.GIF"));
		//
		// jTextField1
		//
		jTextField1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e)
			{
				jTextField1_actionPerformed(e);
			}

		});
		//
		// jTextField2
		//
		jTextField2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e)
			{
				jTextField2_actionPerformed(e);
			}

		});
		//
		// jTextField3
		//
		jTextField3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e)
			{
				jTextField3_actionPerformed(e);
			}

		});
		//
		// jPasswordField1
		//
		jPasswordField1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e)
			{
				jPasswordField1_actionPerformed(e);
			}

		});
		//
		// jButton1
		//
		jButton1.setText("ADD");
		jButton1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e)
			{
				jButton1_actionPerformed(e);
			}

		});


		jButton2.setText("CLEAR");
		jButton2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e)
			{
				jButton2_actionPerformed(e);
			}

		});
		//
		// contentPane
		//
		contentPane.setLayout(null);
		addComponent(contentPane, jLabel1, 71,25,328,25);
		addComponent(contentPane, jLabel2, 40,100,153,25);
		addComponent(contentPane, jLabel3, 38,161,152,26);
		addComponent(contentPane, jLabel4, 39,234,165,26);
		addComponent(contentPane, jLabel5, 40,305,155,26);

		addComponent(contentPane, jTextField1, 280,96,130,28);
		addComponent(contentPane, jTextField2, 283,230,126,27);
		addComponent(contentPane, jTextField3, 285,297,127,28);
		addComponent(contentPane, jPasswordField1, 282,162,129,28);
		addComponent(contentPane, jButton1, 80,386,96,30);
		addComponent(contentPane, jButton2, 270,386,96,30);
		addComponent(contentPane, jLabel6, -6,-1,473,525);
		//
		// UserRegistrationFinal
		//
		this.setTitle("UserRegistrationFinal - extends JFrame");
		this.setLocation(new Point(0, 0));
		this.setSize(new Dimension(473, 525));
	}

	/** Add Component Without a Layout Manager (Absolute Positioning) */
	private void addComponent(Container container,Component c,int x,int y,int width,int height)
	{
		c.setBounds(x,y,width,height);
		container.add(c);
	}

	//
	// TODO: Add any appropriate code in the following Event Handling Methods
	//
	private void jTextField1_actionPerformed(ActionEvent e)
	{
		System.out.println("\njTextField1_actionPerformed(ActionEvent e) called.");
		// TODO: Add any handling code here

	}

	private void jTextField2_actionPerformed(ActionEvent e)
	{
		System.out.println("\njTextField2_actionPerformed(ActionEvent e) called.");
		// TODO: Add any handling code here

	}

	private void jTextField3_actionPerformed(ActionEvent e)
	{
		System.out.println("\njTextField3_actionPerformed(ActionEvent e) called.");
		// TODO: Add any handling code here

	}

	private void jPasswordField1_actionPerformed(ActionEvent e)
	{
		System.out.println("\njPasswordField1_actionPerformed(ActionEvent e) called.");
		// TODO: Add any handling code here

	}

	private void jButton1_actionPerformed(ActionEvent e)
	{
		//System.out.println("\njButton1_actionPerformed(ActionEvent e) called.");
		// TODO: Add any handling code here

		 String s1=jTextField1.getText().trim();
         String s2=jPasswordField1.getText().trim();  
         String s3=jTextField2.getText().trim();
	     String s4=jTextField3.getText().trim();
 			try
 		     {
 				
				if(nuser>0)
 				{
 				
 	             System.out.println(s1);
 	             System.out.println(s2);
				 rs= st.executeQuery("select * from login where username='"+s1+"' OR password1='"+s2+"'");
 	            if(rs.next())
 	            {
 	            	JOptionPane.showMessageDialog(this,"  user  already exist  ");
 	            }
 	            else
 	            	{	
 	            	   	st.executeUpdate("insert into login values('"+uno+"','"+s1+"','"+s2+"','"+s3+"','"+s4+"')");
					   	System.out.println("successfully added");
		                JOptionPane.showMessageDialog(null,"Successfully added");
 	            		nuser--;
						uno++;
 	                    if(nuser==0)
						{
							this.setVisible(false);
							

						}
 	                }
 				}
				else
 			      JOptionPane.showMessageDialog(this,"limit over");
 	           System.out.println("User Count"+nuser);
 			}catch(Exception ee)
				{
				  System.out.println("error in db");
 				  ee.printStackTrace();
				  }
 			finally
 			{
 				jTextField1.setText("");
		        jPasswordField1.setText("");
				jTextField2.setText("");
				jTextField3.setText("");
 				
 			}
 			

	}
	private void jButton2_actionPerformed(ActionEvent e)
	{
		//System.out.println("\njButton2_actionPerformed(ActionEvent e) called.");
		// TODO: Add any handling code here
	        	jTextField1.setText("");
		        jPasswordField1.setText("");
				jTextField2.setText("");
				jTextField3.setText("");

	}


	//
	// TODO: Add any method code to meet your needs in the following area
	//






























 

//============================= Testing ================================//
//=                                                                    =//
//= The following main method is just for testing this class you built.=//
//= After testing,you may simply delete it.                            =//
//======================================================================//
	public static void main(String[] args)
	{
		JFrame.setDefaultLookAndFeelDecorated(true);
		JDialog.setDefaultLookAndFeelDecorated(true);
		try
		{
			UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
		}
		catch (Exception ex)
		{
			System.out.println("Failed loading L&F: ");
			System.out.println(ex);
		}
	//	new UserRegistrationFinal();
	}
//= End of Testing =


}
