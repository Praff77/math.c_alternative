import java.io.*;
import java.util.*;
import java.sql.*;
import java.net.*;

class chart
{
	static int data;
	static String f,fs;
      private String sname="";
	public void values(int value,String f1,String f2)
	{
		 data=value;
		System.out.println("data :"+data);
		 f=f1;
		 fs=f2;
		 String s=data+"#"+f+"#"+fs;
		 chart nn = new chart();
		 nn.chartvalue();
		 
	}

	public ArrayList<String> chartvalue()
	{String p;
	String priv="2";
	String tot;
	int ipriv=Integer.parseInt(priv);
		
	 int tt=0;
	 String gve="";
    
		ArrayList<String> str=new ArrayList<String>();
		try
		{
			
	/*	Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
		Connection con=DriverManager.getConnection("jdbc:odbc:bidirectional");
		Statement st=con.createStatement();*/
		//DbConnection db=new DbConnection();
		//Statement st=db.DBConnect();
		
		    try
		    {
				getServerHostName();
		   
               Socket es1 = new Socket(sname,9876);
			   ObjectOutputStream en1 = new ObjectOutputStream(es1.getOutputStream());
		       ObjectInputStream en2=new ObjectInputStream(es1.getInputStream());
			   en1.writeObject("1");
			   en1.writeObject("keysize");
               gve=(String)en2.readObject();
		       en1.writeObject("");
			   en1.writeObject("");
			   en1.writeObject("");
               es1.close();
             }
		    catch (Exception esc)
		    {
				esc.printStackTrace();
		    }

          System.out.println(gve);


           str.add(gve);




		/*ResultSet rs=st.executeQuery("select * from keysize");
		
		while(rs.next())
		{
			String pp=rs.getString(1);
			//System.out.println("PP:"+pp);
			 
             int tkey=2+Integer.parseInt(pp);
			  String totkey=Integer.toString(tkey);
			 p=rs.getString(1)
				 +"#"+String.valueOf(rs.getInt(2))+"#"+rs.getString(3);
                 String keys="2"+"#"+pp+"#"+totkey;
               //  tt=Integer.parseInt(keys);

				// int 
				// p=priv+"#"+keys+"#"+tt;
			 System.out.println(keys);
			str.add(keys);
		}*/
		 

		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		
		 
		
		
		//System.out.println("pppp"+p);
		
		return str;

	}
	


   public void getServerHostName()
	 {

		try
		{

			FileInputStream fis=new FileInputStream("server.txt");
			byte b[]=new byte[fis.available()];
			fis.read(b);
		    sname= new String(b);
			System.out.println("SERVER NAME IS "+sname);

		}

		catch (Exception e)
		{
		}
	
	}
  



}
